# your code goes here
#!/usr/bin/python
import datetime 
import sys

monthlength = { "jan":31,"mar":31,"apr":30,"may":31,"jun": 30,"jul":31,"aug":31,"sep":30,"oct":31,"nov":30,"dec":31}
monthsdic = { 1:"jan",2:"feb",3:"mar",4:"apr",5:"may",6:"jun",7:"jul",8:"aug",9:"sep",10:"oct",11:"nov",12:"dec"}
daysdic={1:"Sun",2:"Mon",3:"Tue",4:"Wed",5:"Thu",6:"Fri",7:"Sat"}
helpstr="\nThis is a special calender application that help you navigate to today's day in future\
                \nor past calender months,\n But limited to a span of 24 months that is from 12 month in past to\
                    \n12 month in future.\n Inorder to have a successful result please provide an integer ranging\
                        \nfrom -12 to 12, inclusive of limits, as argument where -ve of a number means month in past\
                            \nand +ve means future\n for example -1 will mean accessing today date in previous month \
                                \nand -2 means today in previous to previous month and simliarly future months for +ve \
                                    \nnumber\n If run with 'help' string it will display the details of about and howto \
                                        \nof application \n Arguments are optional, if run with no arguments it \
                                            \nwill display calender of present month \n Hope it helps\
                                                \n regards\n  Mohd Shahid Khan Afridi \n Incoming SE at cisco"

def args_error(): #error message for invalid input
    return "please enter a valid argument, an integer in [-12, 12] or a string '-help' for more assisstance "

def args_valid(): #check validity of commanline argument
        args1=sys.argv[1]; 
        if(args1=='-help'): #provide assistance
            print(helpstr)
            return 0
        try:
            shift=int(args1)
        except: #not an integer
            print(args_error())
            return 0
        if(abs(shift)<=12): # integer not in range
            return 1
        else:
            print(args_error())
            return 0
 
def printweek(day_): #print week days
        dayind_=0
        for i in range(1,8): #iterate in week days
            print(daysdic[i], end=" ")
            if(daysdic[i]==day_):
                dayind_=i
        return dayind_

def numdays(year, month): #return number of days in a given month
    num=0
    if (monthsdic[month] in monthlength):
        num=monthlength[monthsdic[month]] #pick from dictionary
    else: #leap year check for feb
        if(year%4==0):
            num=29
        else:
            num=28
    return num

def printmonth(year, month,dayind, date1,act_date): #print a given month
       rem=date1%7 
       dayind=dayind-rem+1; #to get first date day of the month
       if(dayind<=0): #avoid week overflow || underflow
           dayind=dayind+7
       if(dayind>7):
           dayind=dayind%7+1
       daysnum=numdays(year, month) #getting number of days
       for i in range (1,dayind):
           if (dayind==1):
               break
           print ("   ", end=" ")
       daysnum=daysnum+1
       if(daysnum-1<act_date): #if todays day not present in this month replacing it with last day of month
           act_date=daysnum-1
       for i in range(1,daysnum): #loop over dates
           if(i==act_date): #todays date
               if(dayind==7):
                   print("\x1b[6;37;42m%d\x1b[0m"%(i))
                   dayind=1
               else:
                   print("\x1b[6;30;42m%d\x1b[0m"%(i), end=" ")
                   dayind=dayind+1
           else:
               if (dayind==7): # week over new line for next day
                   print(i)
                   dayind=1
               else:
                   if(i<10):
                       print(i, end="   ")
                   else:
                       print(i, end="  ")
                   dayind=dayind+1  

def calenderbackward(parameter,jump,year,currmon,date,day,dayind): # will fetch todays day in future month
    if(parameter<0):
        jump=date #tracking number of days to go back
        newmon=1
        if(currmon+parameter<=0): #if got to go to previous year
            for i in range(1,currmon): #current year months
                jump=jump+numdays(year, i)
                newmon=i;
            year=year-1
            for i in range(0,-parameter-currmon+1): #previous year months
                jump=jump+numdays(year, 12-i)
                newmon=12-i
        else: 
            newmon=currmon+parameter
            for i in range(newmon, currmon):
                jump=jump+numdays(year,i)
        rem=jump%7 #printing the finaly months and date below
        print(" ")
        print("        ", monthsdic[newmon], year)
        dayind=printweek(day)
        dayind=dayind-rem+1
        if(dayind<=0):
            dayind=dayind+7
        print(" ")
        printmonth(year, newmon, dayind, 1,date)
    
def calenderforward(parameter,jump,year,currmon,date,day,dayind):
    if(parameter>0):
        flag=1 #to track if we jump to next year while travelling in future and update year
        newmon=1
        for i in range(1,parameter): # count number of days to go ahead
            if(currmon+i>12 and flag): # first month in next year 
                year=year+1
                flag=0
            if(currmon+i>12): # months in next year
                jump=jump+numdays(year,(currmon+i)%12)
            else:
                jump=jump+numdays(year,currmon+i) #adding number od dayf in present month to jump
        jump=jump+numdays(year, currmon)-date
        newmon=currmon+parameter
        if(newmon>12):
            if(flag):
                year=year+1
            newmon=newmon%12
        print(" ")
        print("        ", monthsdic[newmon], year)
        dayind=printweek(day) # print week days name
        dayind=dayind+jump%7
        if(dayind>=7):
            dayind=dayind%7+1
        else:
            dayind=dayind+1
        print(" ")    
        printmonth(year, newmon, dayind, 1,date) # print month with a known day and date
    
    

def main():
   
    print("*******WELCOME TO SPECIAL CALENDAR APPLICATION*******")
    
    parameter=0
    if(len(sys.argv)==1): # no argument
        parameter=0
    else:
        if(args_valid()): # checking if input is valid integer
            parameter= int(sys.argv[1])
        else:
            return
        
    #to get and segrigate datetime element
    now = datetime.datetime.today()
    print("     ",now)
    
    year = int(now.strftime("%Y"))
    date=int(now.strftime("%d"))
    month = int(now.strftime("%m"))
    day=now.strftime('%A')
    day=day[0:3]
    dayind=0
    
          
    if(parameter==0): #displays this month and today
        print(" ")
        print("        ", monthsdic[month], year)
        dayind=printweek(day)
        print(" ")
        printmonth(year, month, dayind, date,date)
    
    currmon=month
    jump=0 #to hold the number of to go ahead or back
    
    if(parameter<0): #call for previous months
        calenderbackward(parameter, jump, year, currmon, date, day, dayind)
        
    if(parameter>0): #call for future months
        calenderforward(parameter, jump, year, currmon, date, day, dayind)
        
if __name__=="__main__": 
    main()
        
        
    
